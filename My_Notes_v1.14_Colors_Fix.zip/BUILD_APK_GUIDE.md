# Speech Collection — build-ready source

This ZIP contains the Android Java source project plus a GitHub Actions workflow intended to build a debug APK in a cloud runner. The workflow has **not** been run from this chat, so the APK build is not yet verified.

## What is preserved
- Existing Java Android app and XML layout
- Photo selection and Gemini handwriting OCR/review flow
- Editable “Review scanned notes” dialog
- Display-only main notes panel (keyboard disabled there)
- Normal skip 3 words and long-press skip 20 words
- Existing playback, Memory Card, timer, and other included project features

## Cloud build workflow
1. Upload the contents of this folder to a GitHub repository (the Android project root is this folder).
2. In the repository, open **Actions** and select **Build Speech Collection APK**.
3. Choose **Run workflow** (or push to `main`/`master`).
4. When the run succeeds, open the run and download the artifact named `Speech-Collection-debug-APK`.
5. The artifact contains `app-debug.apk` for testing. A debug APK is not a Play Store release and is not signed with a private release key.

## Important
The workflow is a build route, not proof of a successful build. If it fails, open the Actions run logs and fix the reported error before treating the APK as ready. Never put a private signing key or a Gemini API key into the repository.
