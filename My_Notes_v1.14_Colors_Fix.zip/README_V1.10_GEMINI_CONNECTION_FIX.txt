Speech Collection TTS V1.10 - Gemini OCR Reliability Upgrade

Purpose
- Improve communication between Speech Collection and Gemini for handwritten-note scans.
- Use Gemini's regular generateContent endpoint rather than parsing server-sent streaming chunks.
- Do not show OCR text until Gemini returns a complete response for every selected image.

Changes
- Uses the complete JSON response from generateContent, which is easier to validate than streamed fragments.
- Increases connection timeout to 25 seconds and response timeout to 120 seconds.
- Retries transient network I/O errors (including connection abort/reset and timeouts) as well as temporary HTTP errors.
- Automatically tries the configured fallback model after retryable primary-model failures.
- Detects Gemini responses cut off by the output-token limit and reports that clearly rather than accepting truncated notes.
- Keeps the Gallery-only photo picker, up to 10 selected images, existing review dialog, Memory Card, speech controls, and app layout unchanged.
- Existing notes are not changed when the OCR request fails; scanned text is only added after successful completion and review.

How to test
1. Build and install this project over the previous app (keep the same package/application ID).
2. Confirm the existing Gemini API key is still saved.
3. Select one clear handwritten page from Gallery and wait for the review dialog.
4. Test a dense page; then test multiple pages. If the connection drops, the app should retry and show a clearer error if it still cannot complete.
5. Review the scanned text before tapping Add to notes.

Notes
- OCR accuracy still depends on image clarity and the handwriting itself. Review the result before using it.
- Gemini API access, quotas, billing, and model availability depend on the Google API project/key.
- The API key remains stored locally in the app's SharedPreferences; do not publish an unrestricted key.
