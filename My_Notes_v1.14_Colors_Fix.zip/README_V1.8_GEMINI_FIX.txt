Speech Collection TTS V1.9 - Gemini Handwriting Fix

Changes from V1.7:
- Keeps gallery/photo picker only; camera is never opened.
- Sends selected images to Gemini using the current generateContent REST request structure.
- Uses Gemini 3.8 Flash first, with Gemini 3.5 Flash-Lite as a fallback for model-access/configuration 400/404 errors.
- Uses the x-goog-api-key request header.
- Keeps handwriting transcription conservative: preserve meaning, headings, numbering, examples and paragraph order; correct only obvious errors.
- Shows Google's actual API error message instead of a generic HTTP 400 blob.
- Stops processing on the first API error so one clear diagnostic is shown.
- Increased network timeout to 60 seconds.
- Version 1.8, versionCode 8.

Build:
Open the project in Android Studio/AndroidIDE and run the normal debug build.
The provided environment cannot execute this project's Gradle wrapper because its wrapper expects a system Gradle executable that is not installed here.

API key:
Enter the user's own Gemini API key in Settings > Handwriting AI Settings. The key is stored locally in SharedPreferences. Do not share the key publicly.
