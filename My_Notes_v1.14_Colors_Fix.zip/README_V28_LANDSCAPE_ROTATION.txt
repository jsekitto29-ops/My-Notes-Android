V28 - LANDSCAPE ROTATION

Changed the main activity from portrait-locked to sensor orientation so the app can rotate into landscape when the phone is turned. Added orientation|screenSize configChanges to avoid recreating MainActivity during rotation, helping preserve the current in-memory screen state.

Build and test on device: rotate between portrait and landscape while on the main screen, OCR review screen, and settings. Verify text fields and buttons remain usable in landscape.
