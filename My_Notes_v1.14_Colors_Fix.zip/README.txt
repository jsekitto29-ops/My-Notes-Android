Speech Collection TTS V1.5 – Photo Notes Import

NEW:
- Added a gallery/photo button in the top bar.
- The button ONLY lets you choose existing photos. It does not open the camera.
- Multiple note photos can be selected at once.
- Photos are processed with Google ML Kit Latin text recognition.
- OCR results are shown in a review/edit box before being added to the notes.
- Conservative correction fixes a small set of obvious OCR/spelling mistakes and punctuation spacing.
- You can choose Cancel, Use original, or Add to notes.

IMPORTANT:
Handwriting recognition is harder than printed text. The OCR engine may make mistakes on unclear handwriting, unusual writing, shadows, or low-resolution photos. Always review the text before saving/using it.

BUILD:
Open the project in Android Studio/AndroidIDE with internet access so Gradle can download:
com.google.mlkit:text-recognition:16.0.1
Then build/install the debug APK.


V1.10 Gemini OCR reliability changes are documented in README_V1.10_GEMINI_CONNECTION_FIX.txt.
