package com.example.speechcollectiontts;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.ClipData;
import android.content.SharedPreferences;
import android.net.Uri;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.text.Editable;
import android.text.Spannable;
import android.text.style.ReplacementSpan;
import android.text.TextWatcher;
import android.view.View;
import android.view.MotionEvent;
import android.graphics.drawable.GradientDrawable;
import android.widget.*;
import java.util.*;
import java.util.regex.Pattern;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONArray;
import org.json.JSONObject;
import androidx.exifinterface.media.ExifInterface;


public class MainActivity extends Activity {
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private EditText notes;
    private ImageButton playPauseButton, restartButton, back3Button, next3Button, timerButton, importPhotosButton, memoryCardButton;
    private ProgressBar imageProcessingSpinner;
    private TextView imageProcessingLabel;
    private ImageButton editNotesButton, addNotesButton, copyNotesButton;
    
    private final Handler handler = new Handler(Looper.getMainLooper());

    private static class SpeechToken {
        final String speech;
        final int start;
        final int end;
        final boolean word;
        SpeechToken(String speech, int start, int end, boolean word) {
            this.speech = speech;
            this.start = start;
            this.end = end;
            this.word = word;
        }
    }

    private final List<SpeechToken> tokens = new ArrayList<SpeechToken>();
    private int currentWord = 0;
    private boolean playing = false;
    private boolean paused = false;
    private boolean waitingForNext = false;
    private int breakSeconds = 3;
    private float speechRate = 0.70f;
    private int option2WordCount = 0;
    private String lastText = "";
    private ThickUnderlineSpan currentUnderline;
    private boolean applyingHighlight = false;
    private static final int PICK_IMAGES_REQUEST = 4101;
    private static final String MEMORY_PREF_TEXT = "memory_saved_text";
    private static final String MEMORY_PREF_WORD = "memory_saved_word";
    private static final String MEMORY_PREF_EXISTS = "memory_saved_exists";
    private static final String SAVED_WORKS_PREF = "saved_works_json";
    private static final String RECOVERY_TEXT_PREF = "recovery_text";
    private static final String RECOVERY_WORD_PREF = "recovery_word";
    private static final String BREAK_MODE_PREF = "break_mode_v25";
    private static final String THREE_WORD_PAUSE_PREF = "three_word_pause_v25";
    private static final int OCR_CONNECT_TIMEOUT_MS = 25000;
    private static final int OCR_READ_TIMEOUT_MS = 120000;
    private static final int GEMINI_MAX_RETRIES = 2;
    private static final String GEMINI_MODEL = "gemini-3.8-flash";
    private static final String GEMINI_FALLBACK_MODEL = "gemini-3.5-flash-lite";

    private static final Pattern BREAK_TAG = Pattern.compile("<break\\s+time=\\\"[0-9]+s\\\"\\s*/>", Pattern.CASE_INSENSITIVE);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN,
                android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);

        notes = (EditText) findViewById(R.id.notesEditText);
        // The main notes panel is display-only: users add/edit scanned text in Review Scanned Notes.
        // Keep EditText internally so existing playback highlighting and scrolling continue to work,
        // but prevent typing and never summon the soft keyboard from the main panel.
        notes.setKeyListener(null);
        notes.setShowSoftInputOnFocus(false);
        notes.setCursorVisible(false);
        notes.setFocusable(false);
        notes.setFocusableInTouchMode(false);
        playPauseButton = (ImageButton) findViewById(R.id.playPauseButton);
        restartButton = (ImageButton) findViewById(R.id.restartButton);
        back3Button = (ImageButton) findViewById(R.id.back3Button);
        next3Button = (ImageButton) findViewById(R.id.next3Button);
        timerButton = (ImageButton) findViewById(R.id.timerButton);
        importPhotosButton = (ImageButton) findViewById(R.id.importPhotosButton);
        memoryCardButton = (ImageButton) findViewById(R.id.memoryCardButton);
        imageProcessingSpinner = (ProgressBar) findViewById(R.id.imageProcessingSpinner);
        imageProcessingLabel = (TextView) findViewById(R.id.imageProcessingLabel);
        editNotesButton = (ImageButton) findViewById(R.id.editNotesButton);
        addNotesButton = (ImageButton) findViewById(R.id.addNotesButton);
        copyNotesButton = (ImageButton) findViewById(R.id.copyNotesButton);
        ImageButton settings = (ImageButton) findViewById(R.id.settingsButton);

        loadPreferences();
        offerSavedWorkOnStartup();

        notes.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!applyingHighlight && playing) {
                    stopInternal();
                    tokens.clear();
                    currentWord = 0;
                    lastText = "";
                    clearHighlight();
                    updateControls();
                }
            }
            @Override public void afterTextChanged(Editable s) { }
        });

        importPhotosButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { chooseNotePhotos(); }
        });
        memoryCardButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showMemoryCardDialog(); }
        });
        editNotesButton.setOnClickListener(v -> showEditNotesDialog());
        addNotesButton.setOnClickListener(v -> showAddNotesOptions());
        copyNotesButton.setOnClickListener(v -> copyNotesToClipboard());
        settings.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showSettingsDialog(); }
        });
        playPauseButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { playOrPause(); }
        });
        restartButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { restartReading(); }
        });
        back3Button.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { skipWords(-3); }
        });
        back3Button.setOnLongClickListener(new View.OnLongClickListener() {
            @Override public boolean onLongClick(View v) { skipWords(-20); return true; }
        });
        next3Button.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { skipWords(3); }
        });
        next3Button.setOnLongClickListener(new View.OnLongClickListener() {
            @Override public boolean onLongClick(View v) { skipWords(20); return true; }
        });
        timerButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { cycleBreakTime(); }
        });

        initTts();
        updateControls();
    }

    /** Multiple named works. Each work stores its title, text and reading position locally. */
    private void showMemoryCardDialog() {
        final ArrayList<String> titles = getSavedWorkTitles();
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (18 * getResources().getDisplayMetrics().density);
        box.setPadding(pad, 0, pad, 0);

        TextView info = new TextView(this);
        info.setText(titles.isEmpty()
                ? "Save this work with its own title so you can return to it later."
                : "You can save many different works. Choose one to continue, or save the current work with a new title.");
        info.setTextSize(14);
        info.setTextColor(Color.DKGRAY);
        info.setPadding(0, 0, 0, pad / 2);
        box.addView(info);

        Button save = new Button(this);
        save.setText("Save current work");
        save.setAllCaps(false);
        save.setOnClickListener(v -> showSaveWorkTitleDialog());
        box.addView(save);

        if (!titles.isEmpty()) {
            Button open = new Button(this);
            open.setText("Open a saved work");
            open.setAllCaps(false);
            open.setOnClickListener(v -> showSavedWorksList());
            box.addView(open);
        }

        new AlertDialog.Builder(this)
                .setTitle("Memory Card")
                .setView(box)
                .setPositiveButton("Done", null)
                .show();
    }

    private void showSaveWorkTitleDialog() {
        final String currentText = notes.getText().toString().trim();
        if (currentText.isEmpty()) {
            Toast.makeText(this, "There are no notes to save yet.", Toast.LENGTH_SHORT).show();
            return;
        }
        final EditText titleBox = new EditText(this);
        titleBox.setSingleLine(true);
        titleBox.setHint("e.g. History Notes");
        new AlertDialog.Builder(this)
                .setTitle("Name this work")
                .setMessage("Enter a name or title for this work.")
                .setView(titleBox)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Save", (d, w) -> {
                    String title = titleBox.getText().toString().trim();
                    if (title.isEmpty()) title = "Untitled Work";
                    saveNamedWork(title, currentText, currentWord);
                    Toast.makeText(this, "Saved: " + title, Toast.LENGTH_SHORT).show();
                }).show();
    }

    private ArrayList<String> getSavedWorkTitles() {
        ArrayList<String> titles = new ArrayList<String>();
        String json = getSharedPreferences("speech_collection", MODE_PRIVATE).getString(SAVED_WORKS_PREF, "[]");
        try {
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) titles.add(arr.getJSONObject(i).optString("title", "Untitled Work"));
        } catch (Exception ignored) { }
        return titles;
    }

    private JSONArray getSavedWorksArray() {
        String json = getSharedPreferences("speech_collection", MODE_PRIVATE).getString(SAVED_WORKS_PREF, "[]");
        try { return new JSONArray(json); } catch (Exception e) { return new JSONArray(); }
    }

    private void saveNamedWork(String title, String text, int wordPosition) {
        try {
            JSONArray arr = getSavedWorksArray();
            JSONObject work = new JSONObject();
            work.put("title", title);
            work.put("text", text);
            work.put("word", Math.max(0, wordPosition));
            work.put("savedAt", System.currentTimeMillis());
            arr.put(work);
            getSharedPreferences("speech_collection", MODE_PRIVATE).edit()
                    .putString(SAVED_WORKS_PREF, arr.toString()).apply();
        } catch (Exception e) {
            Toast.makeText(this, "Could not save this work.", Toast.LENGTH_LONG).show();
        }
    }

    private void showSavedWorksList() {
        final JSONArray arr = getSavedWorksArray();
        if (arr.length() == 0) {
            Toast.makeText(this, "No saved works yet.", Toast.LENGTH_SHORT).show();
            return;
        }
        String[] titles = new String[arr.length()];
        for (int i = 0; i < arr.length(); i++) {
            titles[i] = arr.optJSONObject(i).optString("title", "Untitled Work");
        }
        new AlertDialog.Builder(this)
                .setTitle("Saved works")
                .setItems(titles, (d, which) -> showSavedWorkActions(which))
                .setNegativeButton("Close", null)
                .show();
    }

    private void showSavedWorkActions(final int index) {
        final JSONArray arr = getSavedWorksArray();
        if (index < 0 || index >= arr.length()) return;
        final JSONObject work = arr.optJSONObject(index);
        if (work == null) return;
        final String title = work.optString("title", "Untitled Work");
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setItems(new String[]{"Continue this work", "Delete this work"}, (d, which) -> {
                    if (which == 0) loadNamedWork(index);
                    else deleteNamedWork(index, title);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void loadNamedWork(int index) {
        JSONArray arr = getSavedWorksArray();
        JSONObject work = arr.optJSONObject(index);
        if (work == null) return;
        String text = work.optString("text", "");
        if (text.trim().isEmpty()) return;
        stopInternal();
        applyingHighlight = true;
        try {
            notes.setText(text);
            notes.setSelection(notes.length());
        } finally { applyingHighlight = false; }
        tokens.clear();
        lastText = "";
        currentWord = Math.max(0, work.optInt("word", 0));
        clearHighlight();
        updateControls();
        Toast.makeText(this, "Loaded: " + work.optString("title", "Saved work"), Toast.LENGTH_SHORT).show();
    }

    private void deleteNamedWork(int index, String title) {
        JSONArray arr = getSavedWorksArray();
        if (index >= 0 && index < arr.length()) arr.remove(index);
        getSharedPreferences("speech_collection", MODE_PRIVATE).edit().putString(SAVED_WORKS_PREF, arr.toString()).apply();
        Toast.makeText(this, "Deleted: " + title, Toast.LENGTH_SHORT).show();
    }

    private void saveRecoveryCopy() {
        if (notes == null || notes.getText().toString().trim().isEmpty()) return;
        getSharedPreferences("speech_collection", MODE_PRIVATE).edit()
                .putString(RECOVERY_TEXT_PREF, notes.getText().toString())
                .putInt(RECOVERY_WORD_PREF, currentWord).apply();
    }

    @Override protected void onPause() {
        saveRecoveryCopy();
        super.onPause();
    }

    /** Opens the Android Photo Picker. It shows the user's gallery and never opens the camera. */
    private void chooseNotePhotos() {
        try {
            if (android.os.Build.VERSION.SDK_INT >= 33) {
                Intent intent = new Intent(MediaStore.ACTION_PICK_IMAGES);
                intent.setType("image/*");
                intent.putExtra(MediaStore.EXTRA_PICK_IMAGES_MAX, 10);
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                startActivityForResult(intent, PICK_IMAGES_REQUEST);
            } else {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("image/*");
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                startActivityForResult(intent, PICK_IMAGES_REQUEST);
            }
        } catch (Exception e) {
            Toast.makeText(this, "I couldn't open your photo gallery.", Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_IMAGES_REQUEST || resultCode != RESULT_OK || data == null) return;

        final ArrayList<Uri> images = new ArrayList<Uri>();
        ClipData clip = data.getClipData();
        if (clip != null) {
            for (int i = 0; i < clip.getItemCount() && i < 10; i++) images.add(clip.getItemAt(i).getUri());
        } else if (data.getData() != null) {
            images.add(data.getData());
        }
        if (images.isEmpty()) return;

        String key = getGeminiApiKey();
        if (key.trim().isEmpty()) {
            showGeminiSetupDialog();
            return;
        }

        showImageProcessing("Preparing " + images.size() + (images.size() == 1 ? " image…" : " images…"));
        processGeminiImages(images, 0, new StringBuilder(), key);
    }

    private void showImageProcessing(final String message) {
        runOnUiThread(() -> {
            imageProcessingSpinner.setVisibility(View.VISIBLE);
            imageProcessingLabel.setText(message);
            imageProcessingLabel.setVisibility(View.VISIBLE);
            importPhotosButton.setEnabled(false);
            importPhotosButton.setAlpha(0.55f);
        });
    }

    private void hideImageProcessing() {
        runOnUiThread(() -> {
            imageProcessingSpinner.setVisibility(View.GONE);
            imageProcessingLabel.setVisibility(View.GONE);
            importPhotosButton.setEnabled(true);
            importPhotosButton.setAlpha(1f);
        });
    }

    private void showEditNotesDialog() {
        final EditText editor = new EditText(this);
        editor.setText(notes.getText().toString());
        editor.setGravity(android.view.Gravity.TOP | android.view.Gravity.START);
        editor.setMinLines(8);
        editor.setPadding(24, 20, 24, 20);
        editor.setTextSize(17);
        editor.setInputType(android.text.InputType.TYPE_CLASS_TEXT |
                android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE |
                android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(editor);
        new AlertDialog.Builder(this).setTitle("Edit notes").setView(scroll)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Save changes", (d, w) -> {
                    stopInternal();
                    applyingHighlight = true;
                    notes.setText(editor.getText().toString());
                    notes.setSelection(notes.length());
                    applyingHighlight = false;
                    tokens.clear(); currentWord = 0; lastText = "";
                    clearHighlight(); updateControls();
                    Toast.makeText(this, "Notes updated", Toast.LENGTH_SHORT).show();
                }).show();
    }

    private void showAddNotesOptions() {
        new AlertDialog.Builder(this).setTitle("Add to notes")
                .setItems(new String[]{"Choose image from gallery", "Open saved work"}, (d, which) -> {
                    if (which == 0) chooseNotePhotos();
                    else showSavedWorksList();
                }).setNegativeButton("Cancel", null).show();
    }

    private void copyNotesToClipboard() {
        String text = notes.getText().toString();
        if (text.trim().isEmpty()) {
            Toast.makeText(this, "There are no notes to copy yet.", Toast.LENGTH_SHORT).show();
            return;
        }
        android.content.ClipboardManager clipboard =
                (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(android.content.ClipData.newPlainText("My Notes", text));
        Toast.makeText(this, "Notes copied", Toast.LENGTH_SHORT).show();
    }

    private String getGeminiApiKey() {
        return getSharedPreferences("speech_collection", MODE_PRIVATE).getString("gemini_api_key", "");
    }

    private void processGeminiImages(final ArrayList<Uri> images, final int index, final StringBuilder combined, final String apiKey) {
        if (index >= images.size()) {
            hideImageProcessing();
            final String raw = combined.toString().trim();
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    if (raw.isEmpty()) {
                        Toast.makeText(MainActivity.this, "No readable handwriting was found. Try a clearer, closer photo.", Toast.LENGTH_LONG).show();
                    } else {
                        // Gemini can sometimes return Markdown even when asked for plain text.
                        // Clean Markdown markers locally before the normal OCR cleanup/review.
                        final String cleaned = cleanGeminiFormatting(raw);
                        final String corrected = correctObviousOcrMistakes(cleaned);
                        showOcrReviewDialog(cleaned, corrected);
                    }
                }
            });
            return;
        }

        showImageProcessing("Processing image " + (index + 1) + " of " + images.size() + "…");
        new Thread(new Runnable() {
            @Override public void run() {
                String result = "";
                try {
                    result = geminiHandwritingCorrection(images.get(index), apiKey);
                } catch (Exception e) {
                    Log.e("SpeechCollectionAI", "Gemini failed", e);
                    String message = e.getMessage() == null ? e.toString() : e.getMessage();
                    hideImageProcessing();
                    final String displayMessage = (e instanceof java.io.IOException ||
                            message.toLowerCase(java.util.Locale.ROOT).contains("connection abort") ||
                            message.toLowerCase(java.util.Locale.ROOT).contains("connection reset") ||
                            message.toLowerCase(java.util.Locale.ROOT).contains("timed out"))
                            ? "The connection to Gemini was interrupted. The app retried automatically, but the scan did not finish. Check your internet connection and try again. Your existing notes have not been changed."
                            : (message.contains("HTTP 503") || message.contains("HTTP 429"))
                            ? "Gemini is temporarily busy or rate-limited. The app retried automatically. Please wait a little and try the same photo again."
                            : message;
                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            new AlertDialog.Builder(MainActivity.this)
                                    .setTitle("Handwriting AI error")
                                    .setMessage(displayMessage)
                                    .setPositiveButton("OK", null)
                                    .setNeutralButton("AI settings", (d, w) -> showGeminiSetupDialog())
                                    .show();
                        }
                    });
                    return;
                }
                if (result != null && !result.trim().isEmpty()) {
                    if (combined.length() > 0) combined.append("\n\n");
                    combined.append(result.trim());
                }
                processGeminiImages(images, index + 1, combined, apiKey);
            }
        }).start();
    }

    /** Sends one gallery image to Gemini using a compact multimodal streaming request. */
    private String geminiHandwritingCorrection(Uri uri, String apiKey) throws Exception {
        Bitmap bitmap = decodeBitmapForOcr(uri);
        if (bitmap == null) throw new Exception("The selected image could not be read by the app.");

        ByteArrayOutputStream imageOut = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 82, imageOut);
        bitmap.recycle();
        String encoded = Base64.encodeToString(imageOut.toByteArray(), Base64.NO_WRAP);

        String prompt = "Read this handwritten school-note page and transcribe it into clean editable text. " +
                "Use the whole page and sentence context to resolve unclear handwriting. " +
                "Preserve headings, numbering, bullets, paragraph order, names, dates, examples and formulas. " +
                "Fix only obvious spelling, punctuation, spacing and recognition errors. " +
                "Do not summarize, explain, invent missing information, or reject the page because some words are difficult. " +
                "If a word is uncertain, use the closest readable wording. Return only the cleaned notes as plain text: do not use Markdown, bold markers (**), italic markers (*), heading markers (#), code fences, or other formatting markup.";

        try {
            return callGeminiWithRetry(GEMINI_MODEL, encoded, prompt, apiKey);
        } catch (Exception primaryError) {
            // 503/temporary overload: use the low-latency fallback model automatically.
            if (isRetryableGeminiError(primaryError)) {
                return callGeminiWithRetry(GEMINI_FALLBACK_MODEL, encoded, prompt, apiKey);
            }
            throw primaryError;
        }
    }

    private boolean isRetryableGeminiError(Exception e) {
        // Connection reset/abort and socket timeouts are commonly reported as IOExceptions.
        if (e instanceof java.io.IOException) return true;
        String m = e.getMessage() == null ? "" : e.getMessage();
        String lower = m.toLowerCase(java.util.Locale.ROOT);
        return m.contains("HTTP 503") || m.contains("HTTP 429") || m.contains("HTTP 408") ||
               m.contains("HTTP 500") || m.contains("HTTP 502") || m.contains("HTTP 504") ||
               lower.contains("connection abort") || lower.contains("connection reset") ||
               lower.contains("unexpected end of stream") || lower.contains("socket timeout") ||
               lower.contains("timed out") || lower.contains("incomplete response");
    }

    private String callGeminiWithRetry(String model, String encodedImage, String prompt, String apiKey) throws Exception {
        Exception last = null;
        for (int attempt = 0; attempt <= GEMINI_MAX_RETRIES; attempt++) {
            try {
                return callGeminiGenerateContent(model, encodedImage, prompt, apiKey);
            } catch (Exception e) {
                last = e;
                if (!isRetryableGeminiError(e) || attempt == GEMINI_MAX_RETRIES) break;
                try {
                    long delay = (long) (1200L * Math.pow(2, attempt));
                    Thread.sleep(delay);
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    throw e;
                }
            }
        }
        throw last == null ? new Exception("Gemini request failed.") : last;
    }

    /**
     * Sends one image using Gemini's regular generateContent endpoint.
     * A complete JSON response is easier to validate than streamed chunks and prevents
     * partial chunks from accidentally being treated as finished notes.
     */
    private String callGeminiGenerateContent(String model, String encodedImage, String prompt, String apiKey) throws Exception {
        JSONObject root = new JSONObject();
        JSONArray contents = new JSONArray();
        JSONObject content = new JSONObject();
        content.put("role", "user");
        JSONArray parts = new JSONArray();

        JSONObject textPart = new JSONObject();
        textPart.put("text", prompt);
        parts.put(textPart);

        JSONObject imagePart = new JSONObject();
        JSONObject inline = new JSONObject();
        inline.put("mime_type", "image/jpeg");
        inline.put("data", encodedImage);
        imagePart.put("inline_data", inline);
        parts.put(imagePart);

        content.put("parts", parts);
        contents.put(content);
        root.put("contents", contents);

        JSONObject generationConfig = new JSONObject();
        generationConfig.put("temperature", 0.1);
        generationConfig.put("maxOutputTokens", 12000);
        root.put("generationConfig", generationConfig);

        HttpURLConnection conn = null;
        try {
            URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent");
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setConnectTimeout(OCR_CONNECT_TIMEOUT_MS);
            conn.setReadTimeout(OCR_READ_TIMEOUT_MS);
            conn.setDoOutput(true);
            conn.setUseCaches(false);
            conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            conn.setRequestProperty("Accept", "application/json");
            conn.setRequestProperty("x-goog-api-key", apiKey.trim());

            byte[] body = root.toString().getBytes("UTF-8");
            conn.setFixedLengthStreamingMode(body.length);
            try (OutputStream out = conn.getOutputStream()) {
                out.write(body);
                out.flush();
            }

            int status = conn.getResponseCode();
            InputStream stream = status >= 200 && status < 300 ? conn.getInputStream() : conn.getErrorStream();
            String response = readAll(stream);
            if (status < 200 || status >= 300) {
                throw new Exception("Gemini HTTP " + status + " (" + model + "):\\n" + readableGeminiError(response));
            }

            JSONObject responseJson = new JSONObject(response);
            JSONArray candidates = responseJson.optJSONArray("candidates");
            if (candidates == null || candidates.length() == 0) {
                throw new Exception("Gemini returned no complete answer. Please try the same photo again.");
            }
            JSONObject candidate = candidates.optJSONObject(0);
            if (candidate == null) throw new Exception("Gemini returned an unreadable response. Please try again.");

            String finishReason = candidate.optString("finishReason", "");
            if ("MAX_TOKENS".equalsIgnoreCase(finishReason)) {
                throw new Exception("Gemini's answer was cut short because the notes were too long. Try sending fewer photos at a time.");
            }
            if ("SAFETY".equalsIgnoreCase(finishReason) || "RECITATION".equalsIgnoreCase(finishReason)) {
                throw new Exception("Gemini could not complete this scan. Please try the photo again.");
            }

            JSONObject candidateContent = candidate.optJSONObject("content");
            JSONArray responseParts = candidateContent == null ? null : candidateContent.optJSONArray("parts");
            StringBuilder text = new StringBuilder();
            if (responseParts != null) {
                for (int i = 0; i < responseParts.length(); i++) {
                    JSONObject part = responseParts.optJSONObject(i);
                    if (part != null) {
                        String value = part.optString("text", "");
                        if (!value.isEmpty()) text.append(value);
                    }
                }
            }
            String resultText = text.toString().trim();
            if (resultText.isEmpty()) {
                throw new Exception("Gemini returned no readable text. Please try the photo again.");
            }
            return resultText;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private String readableGeminiError(String response) {
        if (response == null || response.trim().isEmpty()) return "No error details were returned by Google.";
        try {
            JSONObject obj = new JSONObject(response);
            JSONObject error = obj.optJSONObject("error");
            if (error != null) {
                String message = error.optString("message", "");
                String status = error.optString("status", "");
                String code = error.optString("code", "");
                StringBuilder sb = new StringBuilder();
                if (!message.isEmpty()) sb.append(message);
                if (!status.isEmpty()) sb.append("\nStatus: ").append(status);
                if (!code.isEmpty()) sb.append("\nCode: ").append(code);
                return sb.toString();
            }
        } catch (Exception ignored) { }
        return response.length() > 1800 ? response.substring(0, 1800) + "…" : response;
    }

    private String readAll(InputStream stream) throws Exception {
        if (stream == null) return "";
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buffer = new byte[8192];
        int n;
        while ((n = stream.read(buffer)) != -1) out.write(buffer, 0, n);
        stream.close();
        return new String(out.toByteArray(), "UTF-8");
    }

    private Bitmap decodeBitmapForOcr(Uri uri) throws Exception {
        InputStream in = getContentResolver().openInputStream(uri);
        if (in == null) return null;
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeStream(in, null, bounds);
        in.close();
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null;

        int maxDimension = 2200;
        int sample = 1;
        while (bounds.outWidth / sample > maxDimension || bounds.outHeight / sample > maxDimension) sample *= 2;
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inSampleSize = sample;
        opts.inPreferredConfig = Bitmap.Config.ARGB_8888;
        in = getContentResolver().openInputStream(uri);
        Bitmap bitmap = BitmapFactory.decodeStream(in, null, opts);
        in.close();
        if (bitmap == null) return null;

        try {
            InputStream exifIn = getContentResolver().openInputStream(uri);
            if (exifIn != null) {
                ExifInterface exif = new ExifInterface(exifIn);
                int orientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
                exifIn.close();
                int degrees = 0;
                if (orientation == ExifInterface.ORIENTATION_ROTATE_90) degrees = 90;
                else if (orientation == ExifInterface.ORIENTATION_ROTATE_180) degrees = 180;
                else if (orientation == ExifInterface.ORIENTATION_ROTATE_270) degrees = 270;
                if (degrees != 0) {
                    Matrix matrix = new Matrix();
                    matrix.postRotate(degrees);
                    Bitmap rotated = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
                    if (rotated != bitmap) bitmap.recycle();
                    bitmap = rotated;
                }
            }
        } catch (Exception ignored) { }
        return bitmap;
    }

    private void showGeminiSetupDialog() {
        final EditText keyBox = new EditText(this);
        keyBox.setSingleLine(true);
        keyBox.setHint("Paste your Google Gemini API key");
        keyBox.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        keyBox.setText(getGeminiApiKey());
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(pad, 0, pad, 0);
        TextView info = new TextView(this);
        info.setText("The app uses Gemini online to read handwriting and correct obvious mistakes. Only the photos you choose are sent for processing. The camera is never opened.");
        info.setTextSize(13);
        info.setTextColor(Color.DKGRAY);
        info.setPadding(0, 0, 0, pad);
        box.addView(info);
        box.addView(keyBox);

        new AlertDialog.Builder(this)
                .setTitle("Handwriting AI setup")
                .setView(box)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Save", (d, which) -> {
                    getSharedPreferences("speech_collection", MODE_PRIVATE).edit().putString("gemini_api_key", keyBox.getText().toString().trim()).apply();
                    Toast.makeText(this, "AI key saved. Tap the gallery icon again to scan.", Toast.LENGTH_LONG).show();
                }).show();
    }

    /** Conservative cleanup: fixes common OCR/spelling errors without rewriting the student's notes. */
    /**
     * Removes Markdown formatting that Gemini may add to otherwise plain handwritten notes.
     * The editor should show the actual notes, not Markdown control characters such as **.
     */
    private String cleanGeminiFormatting(String text) {
        if (text == null) return "";

        String cleaned = text;

        // Remove fenced-code markers if Gemini ever wraps the notes in a code block.
        cleaned = cleaned.replace("```text", "").replace("```", "");

        // Remove Markdown bold/italic markers. This is intentionally conservative:
        // ordinary punctuation and paragraph breaks are preserved.
        cleaned = cleaned.replace("**", "");
        cleaned = cleaned.replace("__", "");

        // Remove heading markers at the beginning of a line (### Heading -> Heading).
        cleaned = cleaned.replaceAll("(?m)^\\\\s*#{1,6}\\\\s+", "");

        // Convert Markdown bullet stars into normal bullet characters.
        cleaned = cleaned.replaceAll("(?m)^\\\\s*\\\\*\\\\s+", "• ");

        // Remove accidental trailing spaces while preserving paragraph/newline structure.
        cleaned = cleaned.replaceAll("[ \\\\t]+(?=\\\\r?\\\\n)", "");
        cleaned = cleaned.trim();

        return cleaned;
    }

    private String correctObviousOcrMistakes(String text) {
        String s = text.replace('\u2018', '\'').replace('\u2019', '\'')
                .replace('\u201c', '"').replace('\u201d', '"')
                // Gemini can occasionally return a standalone "n" where the source had a line break.
                // Remove it only when it appears immediately after sentence punctuation and before a new sentence.
                // IMPORTANT: use actual newline characters in Java replacement strings, not the literal letter "n".
                .replace("\\n", "\n")
                .replaceAll("(?<=[.!?])\\s*n(?=\\s+[A-Z])", "\n")
                .replaceAll("[ \\t]+", " ")
                .replaceAll(" *([,.;:!?]) *", "$1 ")
                .replaceAll(" +\\n", "\n")
                .replaceAll("\\n{3,}", "\n\\n").trim();
        String[][] fixes = new String[][] {
                {"\\bmoring\\b", "morning"}, {"\\bgentlmen\\b", "gentlemen"},
                {"\\bteh\\b", "the"}, {"\\brecieve\\b", "receive"},
                {"\\bseperate\\b", "separate"}, {"\\bdefinately\\b", "definitely"},
                {"\\bbecuase\\b", "because"}, {"\\bwich\\b", "which"},
                {"\\bthier\\b", "their"}, {"\\bgoverment\\b", "government"},
                {"\\benviroment\\b", "environment"}, {"\\bknowlege\\b", "knowledge"},
                {"\\bpeopel\\b", "people"}, {"\\brecieved\\b", "received"}
        };
        for (String[] fix : fixes) s = s.replaceAll(fix[0], fix[1]);
        return s;
    }

    private void showOcrReviewDialog(String raw, String corrected) {
        final EditText preview = new EditText(this);
        preview.setText(corrected);
        preview.setTextSize(18);
        preview.setGravity(android.view.Gravity.TOP | android.view.Gravity.START);
        preview.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE | android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        int pad = (int) (12 * getResources().getDisplayMetrics().density);
        preview.setPadding(pad, pad, pad, pad);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(pad, 0, pad, 0);
        TextView info = new TextView(this);
        info.setText("Check the scanned handwriting before adding it to your notes. The correction step is deliberately conservative.");
        info.setTextSize(13);
        info.setTextColor(Color.GRAY);
        info.setPadding(0, 0, 0, pad);
        box.addView(info);
        box.addView(preview, new LinearLayout.LayoutParams(-1, (int)(360 * getResources().getDisplayMetrics().density)));
        new AlertDialog.Builder(this)
                .setTitle("Review scanned notes")
                .setView(box)
                .setNegativeButton("Cancel", null)
                .setNeutralButton("Use original", (d, which) -> notes.setText(raw))
                .setPositiveButton("Add to notes", (d, which) -> {
                    String imported = preview.getText().toString().trim();
                    if (!imported.isEmpty()) {
                        String existing = notes.getText().toString().trim();
                        notes.setText(existing.isEmpty() ? imported : existing + "\n\n" + imported);
                        notes.setSelection(notes.length());
                    }
                }).show();
    }

    private void showSettingsDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (18 * getResources().getDisplayMetrics().density);
        box.setPadding(pad, 0, pad, 0);

        Button voiceSettings = new Button(this);
        voiceSettings.setText("Voice Settings");
        voiceSettings.setAllCaps(false);
        voiceSettings.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                try {
                    startActivity(new Intent("com.android.settings.TTS_SETTINGS"));
                } catch (Exception e) {
                    startActivity(new Intent(Settings.ACTION_SETTINGS));
                }
            }
        });

        Button refreshVoice = new Button(this);
        refreshVoice.setText("Refresh Voice");
        refreshVoice.setAllCaps(false);
        refreshVoice.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { initTts(); }
        });

        Button ocrSettings = new Button(this);
        ocrSettings.setText("Handwriting AI Settings");
        ocrSettings.setAllCaps(false);
        ocrSettings.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showGeminiSetupDialog(); }
        });

        TextView speedTitle = new TextView(this);
        speedTitle.setText("Voice speed");
        speedTitle.setTextSize(16);
        speedTitle.setTextColor(Color.DKGRAY);
        speedTitle.setTypeface(null, Typeface.BOLD);
        speedTitle.setPadding(0, pad, 0, 2);

        TextView speedValue = new TextView(this);
        speedValue.setText(speedLabel(speechRate));
        speedValue.setTextSize(14);
        speedValue.setTextColor(Color.GRAY);

        SeekBar speedSlider = new SeekBar(this);
        speedSlider.setMax(13);
        speedSlider.setProgress(rateToProgress(speechRate));
        speedSlider.setContentDescription("Voice speed slider");
        speedSlider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                speechRate = progressToRate(progress);
                speedValue.setText(speedLabel(speechRate));
                savePreferences();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { }
        });

        TextView speedLabels = new TextView(this);
        speedLabels.setText("Very slow                                      Normal");
        speedLabels.setTextSize(12);
        speedLabels.setTextColor(Color.GRAY);

        TextView breakInfo = new TextView(this);
        breakInfo.setText("Speech Break Timer: " + getBreakModeLabel() + "\nPunctuation pause: 1 second");
        breakInfo.setTextSize(13);
        breakInfo.setTextColor(Color.GRAY);
        breakInfo.setPadding(0, pad, 0, 0);

        Button breakTimerSettings = new Button(this);
        breakTimerSettings.setText("Speech Break Timer");
        breakTimerSettings.setAllCaps(false);
        breakTimerSettings.setOnClickListener(v -> showSpeechBreakTimerSettings());

        box.addView(voiceSettings);
        box.addView(refreshVoice);
        box.addView(ocrSettings);
        box.addView(breakTimerSettings);
        box.addView(speedTitle);
        box.addView(speedValue);
        box.addView(speedSlider);
        box.addView(speedLabels);
        box.addView(breakInfo);

        new AlertDialog.Builder(this)
                .setTitle("Speech Collection")
                .setView(box)
                .setPositiveButton("Done", null)
                .show();
    }

    private String getBreakModeLabel() {
        int mode = getSharedPreferences("speech_collection", MODE_PRIVATE).getInt(BREAK_MODE_PREF, 0);
        if (mode == 1) {
            return "Option 2 — 3 words + " + breakSeconds + " seconds";
        }
        return "Option 1 — one word at a time + " + breakSeconds + " seconds";
    }

    private void showSpeechBreakTimerSettings() {
        SharedPreferences p = getSharedPreferences("speech_collection", MODE_PRIVATE);
        int currentMode = p.getInt(BREAK_MODE_PREF, 0);
        final int[] selectedMode = {currentMode};
        String[] modes = {
                "Option 1 — Normal: one word at a time",
                "Option 2 — Read 3 words, then pause"
        };
        new AlertDialog.Builder(this)
                .setTitle("Speech Break Timer")
                .setSingleChoiceItems(modes, currentMode, (dialog, which) -> selectedMode[0] = which)
                .setPositiveButton("Save", (dialog, which) -> {
                    int mode = selectedMode[0];
                    if (mode == 0) {
                        if (breakSeconds < 2 || breakSeconds > 4) breakSeconds = 3;
                    } else {
                        if (breakSeconds < 4 || breakSeconds > 10) breakSeconds = 4;
                    }
                    p.edit().putInt(BREAK_MODE_PREF, mode).putInt("break_seconds", breakSeconds).apply();
                    Toast.makeText(this, mode == 0 ? "Option 1 selected. Timer: 2–4 seconds." : "Option 2 selected. Timer: 4–10 seconds.", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void cycleBreakTime() {
        SharedPreferences p = getSharedPreferences("speech_collection", MODE_PRIVATE);
        int mode = p.getInt(BREAK_MODE_PREF, 0);
        if (mode == 0) {
            // Option 1: 2 -> 3 -> 4 -> 2
            if (breakSeconds < 2 || breakSeconds > 4) breakSeconds = 2;
            else if (breakSeconds == 2) breakSeconds = 3;
            else if (breakSeconds == 3) breakSeconds = 4;
            else breakSeconds = 2;
            p.edit().putInt("break_seconds", breakSeconds).apply();
            Toast.makeText(this, "Normal break: " + breakSeconds + " seconds", Toast.LENGTH_SHORT).show();
        } else {
            // Option 2: 4 -> 5 -> 6 -> 7 -> 8 -> 9 -> 10 -> 4
            if (breakSeconds < 4 || breakSeconds > 10) breakSeconds = 4;
            else if (breakSeconds < 10) breakSeconds++;
            else breakSeconds = 4;
            p.edit().putInt("break_seconds", breakSeconds).apply();
            Toast.makeText(this, "3-word break: " + breakSeconds + " seconds", Toast.LENGTH_SHORT).show();
        }
    }

    private float progressToRate(int progress) { return 0.35f + (progress * 0.05f); }
    private int rateToProgress(float rate) { return Math.max(0, Math.min(13, Math.round((rate - 0.35f) / 0.05f))); }

    private String speedLabel(float rate) {
        if (rate <= 0.45f) return "Very slow";
        if (rate <= 0.60f) return "Slow";
        if (rate <= 0.80f) return "Comfortable";
        if (rate <= 1.00f) return "Normal";
        return "Fast";
    }

    private void offerSavedWorkOnStartup() {
        SharedPreferences p = getSharedPreferences("speech_collection", MODE_PRIVATE);
        final String recovery = p.getString(RECOVERY_TEXT_PREF, "");
        if (recovery.trim().isEmpty()) return;
        new AlertDialog.Builder(this)
                .setTitle("Continue unfinished work?")
                .setMessage("A safety copy of your unfinished notes was found. Do you want to restore it?")
                .setNegativeButton("Start new", null)
                .setPositiveButton("Continue", (d, w) -> {
                    stopInternal();
                    applyingHighlight = true;
                    try { notes.setText(recovery); notes.setSelection(notes.length()); }
                    finally { applyingHighlight = false; }
                    currentWord = Math.max(0, p.getInt(RECOVERY_WORD_PREF, 0));
                    tokens.clear(); lastText = ""; clearHighlight(); updateControls();
                }).show();
    }

    private void loadPreferences() {
        android.content.SharedPreferences p = getSharedPreferences("speech_collection", MODE_PRIVATE);
        int mode = p.getInt(BREAK_MODE_PREF, 0);
        breakSeconds = p.getInt("break_seconds", mode == 1 ? 4 : 3);
        if (mode == 0) {
            if (breakSeconds < 2 || breakSeconds > 4) breakSeconds = 3;
        } else {
            if (breakSeconds < 4 || breakSeconds > 10) {
                int legacy = p.getInt(THREE_WORD_PAUSE_PREF, 5);
                breakSeconds = (legacy >= 5 && legacy <= 6) ? legacy : 4;
            }
        }
        if (!p.contains(BREAK_MODE_PREF)) p.edit().putInt(BREAK_MODE_PREF, 0).apply();
        if (!p.contains(THREE_WORD_PAUSE_PREF)) p.edit().putInt(THREE_WORD_PAUSE_PREF, 5).apply();
        p.edit().putInt("break_seconds", breakSeconds).apply();
        speechRate = p.getFloat("speech_rate", 0.70f);
    }

    private void savePreferences() {
        getSharedPreferences("speech_collection", MODE_PRIVATE)
                .edit()
                .putInt("break_seconds", breakSeconds)
                .putFloat("speech_rate", speechRate)
                .apply();
    }

    private void initTts() {
        stopInternal();
        if (tts != null) {
            try { tts.shutdown(); } catch (Exception ignored) { }
            tts = null;
        }
        ttsReady = false;
        final String configured = Settings.Secure.getString(getContentResolver(), "tts_default_synth");
        final TextToSpeech[] holder = new TextToSpeech[1];
        try {
            holder[0] = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
                @Override public void onInit(int status) {
                    if (status == TextToSpeech.SUCCESS) {
                        int lang = holder[0].setLanguage(Locale.US);
                        if (lang == TextToSpeech.LANG_MISSING_DATA || lang == TextToSpeech.LANG_NOT_SUPPORTED) {
                            lang = holder[0].setLanguage(Locale.UK);
                        }
                        if (lang == TextToSpeech.LANG_MISSING_DATA || lang == TextToSpeech.LANG_NOT_SUPPORTED) {
                            Toast.makeText(MainActivity.this, "English voice is unavailable", Toast.LENGTH_LONG).show();
                            updateControls();
                            return;
                        }
                        tts = holder[0];
                        ttsReady = true;
                        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                            @Override public void onStart(String utteranceId) { }
                            @Override public void onDone(String utteranceId) {
                                runOnUiThread(new Runnable() {
                                    @Override public void run() {
                                        // Ignore callbacks from speech that was stopped/replaced.
                                        if (utteranceId != null && utteranceId.equals("word_" + currentWord)) {
                                            wordFinished();
                                        }
                                    }
                                });
                            }
                            @Override public void onError(String utteranceId) {
                                runOnUiThread(new Runnable() {
                                    @Override public void run() {
                                        waitingForNext = false;
                                        Toast.makeText(MainActivity.this, "Voice error — tap Play to try again", Toast.LENGTH_SHORT).show();
                                        updateControls();
                                    }
                                });
                            }
                        });
                        updateControls();
                    } else {
                        Toast.makeText(MainActivity.this, "Voice could not start. Open the three dots and Refresh Voice.", Toast.LENGTH_LONG).show();
                        updateControls();
                    }
                }
            }, configured);
        } catch (Exception e) {
            Toast.makeText(this, "TTS error: " + e.getClass().getSimpleName(), Toast.LENGTH_LONG).show();
            updateControls();
        }
    }

    private boolean ready() {
        if (!ttsReady || tts == null) {
            Toast.makeText(this, "Voice is still starting. Try again in a moment.", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private void playOrPause() {
        if (!ready()) return;
        if (playing) pauseReading(); else playOrResume();
    }

    private void playOrResume() {
        if (!ready()) return;
        String currentText = notes.getText().toString();
        if (tokens.isEmpty() || currentWord >= tokens.size() || !currentText.equals(lastText)) {
            prepareWords();
            if (currentWord >= tokens.size()) currentWord = 0;
        }
        if (tokens.isEmpty()) {
            Toast.makeText(this, "Type or paste some notes first.", Toast.LENGTH_SHORT).show();
            return;
        }
        playing = true;
        paused = false;
        waitingForNext = false;
        option2WordCount = 0;
        handler.removeCallbacksAndMessages(null);
        if (tts != null) tts.stop();
        speakCurrentWord();
        updateControls();
    }

    private void pauseReading() {
        if (!playing) return;
        playing = false;
        paused = true;
        waitingForNext = false;
        handler.removeCallbacksAndMessages(null);
        if (tts != null) tts.stop();
        updateControls();
    }

    private void restartReading() {
        if (!ready()) return;
        handler.removeCallbacksAndMessages(null);
        if (tts != null) tts.stop();
        prepareWords();
        if (tokens.isEmpty()) {
            Toast.makeText(this, "Type or paste some notes first.", Toast.LENGTH_SHORT).show();
            return;
        }
        currentWord = 0;
        option2WordCount = 0;
        playing = true;
        paused = false;
        waitingForNext = false;
        speakCurrentWord();
        updateControls();
    }

    private void skipWords(final int amount) {
        if (!ready()) return;
        if (tokens.isEmpty() || !notes.getText().toString().equals(lastText)) prepareWords();
        if (tokens.isEmpty()) {
            Toast.makeText(this, "Type or paste some notes first.", Toast.LENGTH_SHORT).show();
            return;
        }
        int target = moveByWords(currentWord, amount);
        currentWord = Math.max(0, Math.min(tokens.size() - 1, target));
        handler.removeCallbacksAndMessages(null);
        waitingForNext = false;
        if (tts != null) tts.stop();
        if (playing) {
            speakCurrentWord();
        } else {
            paused = true;
            applyHighlight(tokens.get(currentWord));
            updateControls();
        }
    }

    private int moveByWords(int from, int amount) {
        if (amount > 0) {
            int index = Math.max(0, Math.min(from, tokens.size() - 1));
            int count = 0;
            while (index < tokens.size() - 1 && count < amount) {
                index++;
                if (tokens.get(index).word) count++;
            }
            return index;
        } else {
            int index = Math.max(0, Math.min(from, tokens.size() - 1));
            int count = 0;
            while (index > 0 && count < -amount) {
                index--;
                if (tokens.get(index).word) count++;
            }
            return index;
        }
    }

    private void prepareWords() {
        clearHighlight();
        tokens.clear();
        String text = BREAK_TAG.matcher(notes.getText().toString()).replaceAll(" ");
        tokenizeForSpeech(text, tokens);
        lastText = notes.getText().toString();
        if (currentWord >= tokens.size()) currentWord = Math.max(0, tokens.size() - 1);
    }

    private void tokenizeForSpeech(String text, List<SpeechToken> result) {
        int wordStart = -1;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (Character.isLetterOrDigit(c)) {
                if (wordStart < 0) wordStart = i;
            } else {
                if (wordStart >= 0) {
                    result.add(new SpeechToken(text.substring(wordStart, i), wordStart, i, true));
                    wordStart = -1;
                }
                if (!Character.isWhitespace(c)) {
                    String name = punctuationName(c);
                    if (name != null) result.add(new SpeechToken(name, i, i + 1, false));
                }
            }
        }
        if (wordStart >= 0) result.add(new SpeechToken(text.substring(wordStart), wordStart, text.length(), true));
    }

    private String punctuationName(char c) {
        switch (c) {
            case '.': return "full stop";
            case ',': return "comma";
            case '?': return "question mark";
            case '!': return "exclamation mark";
            case ':': return "colon";
            case ';': return "semicolon";
            case '\'': return "apostrophe";
            case '"': return "quotation mark";
            case '(' : return "opening bracket";
            case ')' : return "closing bracket";
            case '[' : return "opening square bracket";
            case ']' : return "closing square bracket";
            case '{' : return "opening curly bracket";
            case '}' : return "closing curly bracket";
            case '-': return "hyphen";
            case '—': return "dash";
            case '_': return "underscore";
            case '/': return "slash";
            case '\\': return "backslash";
            case '@': return "at sign";
            case '#': return "hash";
            case '&': return "ampersand";
            case '*': return "asterisk";
            case '+': return "plus sign";
            case '=': return "equals sign";
            case '%': return "percent sign";
            case '$': return "dollar sign";
            case '£': return "pound sign";
            case '€': return "euro sign";
            case '^': return "caret";
            case '~': return "tilde";
            case '`': return "backtick";
            case '<': return "less than";
            case '>': return "greater than";
            case '|': return "vertical bar";
            default: return null;
        }
    }

    private void speakCurrentWord() {
        if (!playing || paused || !ttsReady || tts == null) return;
        if (currentWord >= tokens.size()) {
            finishReading();
            return;
        }
        waitingForNext = false;
        SpeechToken token = tokens.get(currentWord);
        tts.setSpeechRate(speechRate);
        applyHighlight(token);
        tts.speak(token.speech, TextToSpeech.QUEUE_FLUSH, null, "word_" + currentWord);
    }

    private void wordFinished() {
        if (!playing || paused) return;
        SpeechToken finished = currentWord < tokens.size() ? tokens.get(currentWord) : null;
        boolean punctuation = finished != null && !finished.word;
        int mode = getSharedPreferences("speech_collection", MODE_PRIVATE).getInt(BREAK_MODE_PREF, 0);
        int delaySeconds;
        if (punctuation) {
            // Every punctuation mark gets exactly a 1-second pause.
            delaySeconds = 1;
        } else if (mode == 1) {
            // Option 2: three words are read, then the selected 4–10 second pause.
            if (finished != null && finished.word) option2WordCount++;
            if (option2WordCount >= 3) {
                delaySeconds = breakSeconds;
                option2WordCount = 0;
            } else {
                delaySeconds = 0;
            }
        } else {
            // Option 1: normal one-word-at-a-time break.
            delaySeconds = breakSeconds;
        }

        currentWord++;
        if (currentWord >= tokens.size()) {
            finishReading();
            return;
        }
        waitingForNext = true;
        handler.postDelayed(new Runnable() {
            @Override public void run() {
                waitingForNext = false;
                speakCurrentWord();
            }
        }, Math.max(0, delaySeconds) * 1000L);
    }

    private void applyHighlight(SpeechToken token) {
        clearHighlight();
        Editable editable = notes.getText();
        int start = Math.max(0, Math.min(token.start, editable.length()));
        int end = Math.max(start, Math.min(token.end, editable.length()));
        if (start >= end) return;
        applyingHighlight = true;
        currentUnderline = new ThickUnderlineSpan();
        editable.setSpan(currentUnderline, start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        applyingHighlight = false;
        notes.post(new Runnable() {
            @Override public void run() {
                android.text.Layout layout = notes.getLayout();
                if (layout != null && currentUnderline != null) {
                    int startOffset = notes.getText().getSpanStart(currentUnderline);
                    if (startOffset >= 0) {
                        int line = layout.getLineForOffset(startOffset);
                        int targetY = Math.max(0, layout.getLineTop(line) - notes.getHeight() / 3);
                        notes.scrollTo(0, targetY);
                    }
                }
            }
        });
    }

    private void clearHighlight() {
        if (currentUnderline != null) {
            Editable editable = notes.getText();
            try { editable.removeSpan(currentUnderline); } catch (Exception ignored) { }
            currentUnderline = null;
        }
    }

    private static class ThickUnderlineSpan extends ReplacementSpan {
        private final float extraGapPx = 3f;
        private final float thicknessPx = 3f;

        @Override public int getSize(android.graphics.Paint paint, CharSequence text, int start, int end, android.graphics.Paint.FontMetricsInt fm) {
            return Math.round(paint.measureText(text, start, end));
        }

        @Override public void draw(android.graphics.Canvas canvas, CharSequence text, int start, int end,
                                   float x, int top, int y, int bottom, android.graphics.Paint paint) {
            canvas.drawText(text, start, end, x, y, paint);
            float width = paint.measureText(text, start, end);
            android.graphics.Paint linePaint = new android.graphics.Paint(paint);
            linePaint.setStyle(android.graphics.Paint.Style.STROKE);
            linePaint.setStrokeWidth(thicknessPx);
            linePaint.setStrokeCap(android.graphics.Paint.Cap.ROUND);
            linePaint.setColor(paint.getColor());
            float lineY = y + extraGapPx;
            canvas.drawLine(x, lineY, x + width, lineY, linePaint);
        }
    }

    private void finishReading() {
        playing = false;
        paused = false;
        waitingForNext = false;
        handler.removeCallbacksAndMessages(null);
        clearHighlight();
        updateControls();
        Toast.makeText(this, "Finished ✓", Toast.LENGTH_SHORT).show();
    }

    private void stopInternal() {
        playing = false;
        paused = false;
        waitingForNext = false;
        handler.removeCallbacksAndMessages(null);
        if (tts != null) tts.stop();
        clearHighlight();
    }

    private void updateControls() {
        boolean enabled = ttsReady;
        playPauseButton.setEnabled(enabled);
        restartButton.setEnabled(enabled);
        back3Button.setEnabled(enabled);
        next3Button.setEnabled(enabled);
        timerButton.setEnabled(enabled);
        if (playing) {
            playPauseButton.setImageResource(R.drawable.ic_pause);
            playPauseButton.setContentDescription("Pause");
        } else {
            playPauseButton.setImageResource(R.drawable.ic_play);
            playPauseButton.setContentDescription("Play or resume");
        }
        float alpha = enabled ? 1f : 0.45f;
        playPauseButton.setAlpha(alpha);
        restartButton.setAlpha(alpha);
        back3Button.setAlpha(alpha);
        next3Button.setAlpha(alpha);
        timerButton.setAlpha(alpha);
    }

    @Override protected void onDestroy() {
        stopInternal();
        if (tts != null) tts.shutdown();
        super.onDestroy();
    }
}
