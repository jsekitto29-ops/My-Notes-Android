Speech Collection V31 - Long-Press Skip

Changes:
- Removed the “Read from here” popup feature completely.
- Tapping the Previous button skips backward 3 words.
- Long-pressing the Previous button skips backward 20 words.
- Tapping the Next button skips forward 3 words.
- Long-pressing the Next button skips forward 20 words.
- Other app features and the lighter icon styling are retained from V30.

Build and test this Android project before installing it. It has not been compiled or tested on a device in this environment.
