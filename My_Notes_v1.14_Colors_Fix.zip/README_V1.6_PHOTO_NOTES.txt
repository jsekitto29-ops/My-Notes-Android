Speech Collection TTS V1.6 - Photo Notes

WHAT CHANGED
- The top gallery icon opens the Android photo picker/gallery, not the camera.
- On Android 13+ it uses the system Photo Picker, so the app does not need broad access to every photo.
- You can select multiple note photos (up to 10).
- Selected photos are sent online to Gemini 3.8 Flash for handwriting transcription and conservative correction.
- The AI is instructed to preserve headings, numbering, examples, formulas, paragraph order and meaning, and to avoid summarizing.
- A Review Scanned Notes box appears before anything is added to the main notes editor.
- Existing speech playback, word underlining, skip controls and timer remain.

FIRST-TIME SETUP
1. Build/install the app.
2. Open the three-dot menu.
3. Choose Handwriting AI Settings.
4. Enter your Google Gemini API key and tap Save.
5. Tap the gallery/photo icon.
6. Choose one or more handwritten-note photos from the gallery.
7. Review the cleaned text, edit if needed, then tap Add to notes.

IMPORTANT
- The app sends selected photos to Google's Gemini API for processing.
- Do not put an unrestricted API key into a public app. Restrict the key to the APIs/usage you need and monitor usage.
- The API may incur charges depending on your Google account/project and current pricing.
- A human review step is kept because handwriting recognition can still make mistakes.

TECHNICAL
- Android compile/target SDK 33.
- Version 1.6 / versionCode 7.
- Gemini REST endpoint: https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent
- Images are resized before upload and rotated using EXIF orientation when available.
