Speech Collection V29 - Modern UI and Read From Here

Changes:
- Updated the main screen to a compact white/pale-lavender design with rounded header buttons, a rounded note editor, and blue-purple playback buttons.
- Reduced outer spacing so the notes area uses more of the screen.
- Speech Break Timer Option 2 cycles 4, 5, 6, 7, 8, 9, 10 seconds. Option 1 remains 2, 3, 4 seconds.
- Tapping a word in the notes shows a small “Read from here” button near/above that word. Tapping the button begins speech at that word.
- Retains the prior project features and landscape rotation configuration.

Build/testing note:
This source package has not been built or device-tested in this environment because the Gradle executable is unavailable. Please open the project in Android Studio and build/run it to verify layout and touch behavior on the phone.
